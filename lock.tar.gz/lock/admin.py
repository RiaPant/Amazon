from django.contrib import admin


from .models import Table1,Prime,Standard

admin.site.register(Table1)
admin.site.register(Prime)
admin.site.register(Standard)

